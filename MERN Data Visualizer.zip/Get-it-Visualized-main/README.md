# Get-it-Visualized
This is a MERN stack project, that takes excel files as input and gives output, various visualization techniques that includes line chart, bar graph, box plot etc... 
The project offers a convenient way to analyze and present data visually, making it easier for users to interpret and understand the information.
The project aims to provide users with a user-friendly approach to analyze and present data visually, facilitating easier interpretation and understanding of the information.
